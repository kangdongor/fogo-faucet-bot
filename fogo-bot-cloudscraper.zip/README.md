# Fogo Faucet Bot with Proxy

Bot Python untuk klaim faucet dari https://faucet.fogo.io menggunakan proxy dan bypass Cloudflare.

## Cara Pakai

1. Masukkan alamat wallet ke `main.py`
2. Isi file `proxies.txt` dengan daftar IP:PORT
3. Jalankan di Codespaces atau terminal:
   ```
   pip install -r requirements.txt
   python3 main.py
   ```
